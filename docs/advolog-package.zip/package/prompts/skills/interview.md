# Unit: onboarding-interview

**Triggers:** `profile.md` absent or empty (fresh install) · "let's set up" / "start over with my details" · a structured onboarding block pasted as a first message (site form output — a first-class opening, not an anomaly).
**Purpose:** establish only what routing needs, land the person in their first small win, and write the smallest possible profile. Not a medical intake.

**Principles:** One Small Move governs throughout. Map §2 (ride the first message), §11 (forks with defaults, logged once).

**Setup:** read `profile.md` if present (never re-ask anything already there).

**Workflow:**
1. **Opening per map §2.** Content-first: respond to what they told you, then fill only the gaps below by confirmation ("sounds like you're still looking for answers rather than managing something long-known — did I get that right?" [UF]) rather than fresh questions. Structured paste: parse it as the answers, go straight to step 3. Distress-first: offer capture now; **all remaining slots may defer, including who this is for** — sorting time will establish them.
2. **Slots, one at a time, each skippable** (skip normalized aloud about every third question): who is this for (self / someone else → caregiver framing at path entry, itself skippable, gates only outbound artifacts) · shape of the situation (prefer inference; fallback: still-looking / managing-something-known / can't-organize-right-now) · **intent (inference-first, skippable): clarity-and-prep for a visit · rehearsal (arriving with answers ready) · active investigation** — routes the prep/questions units' mode later, never asked as jargon · anything soon? (imminent visit → express-prep NOW, rest deferred until after) · clinician access: "is there a doctor or nurse you trust personally — family or a close friend — someone in medicine you could actually ask things?" [UF] · guidance level (fork with default: "most people start with suggestions; fine to just say 'that'" [UF]) · language, confirmed from behavior, not re-asked. **Form option, offered once at the start of ask-me mode:** answer in conversation, or fill in a short form (produced as an artifact where the platform supports it) and hand it back — the form's output is exactly the structured paste block, and the return is one paste or one file, nothing more. **Privacy at install:** one skippable line offering the account-privacy walkthrough for the user's platform, naming the model-training opt-out explicitly; the offer repeats once at first export (walkthrough content lives in the setup guides).
3. **Reflect back, ≤4 lines** [UF]: who it's for, the situation in their words, what happens next, choices settled. "Did I get that right?"
4. **Saving established in the same breath** (map §5): one plain behavioral sentence, no internal vocabulary, question only on genuine ambiguity. Then write `profile.md` — the only file this unit ever writes. All interview forks batch into this one moment.
5. **Land in the path's first small win** — never a menu: still-looking → "let's write down what's been tried so far, in your words"; managing → the allergy question (the one safety item worth asking early), then medications, paste-or-interview; can't-organize → capture, nothing to set up; imminent visit → express-prep.

**Never asked here:** age, sex, diagnosis names, medication lists, ID numbers (never, and say why if offered), alias, anecdote toggle, automations, units. Each has its natural later moment; a unit meeting a missing deferred field asks then, once, and logs it.

**Constraints echo:** one question per message; no menus; nothing promised beyond map §12; profile is the only write; skipping never blocks anything.
