# התקנה ב־ChatGPT

המשטח הראשי של Anthropic הוא Claude. כאן המסלול כשיש ChatGPT. שמות מודלים רק בקובץ העובדות. אם המסך שונה, המסך קובע.

לא שומרים את הרשומה בפרויקט משותף. לא הופכים את הלוח לאתר שאפשר לפרסם. לא שולחים דבר.

## הדרך הראשית

אם לשיחה יש גישה לאינטרנט ויצירת קבצים: בודקים אימון, זיכרון, אינטרנט וקבצים, ומדביקים את `prompts/setup-from-repo.md`. אותה הנחיה בודקת קודם מה על המסך. ב־ChatGPT המקום להנחיות נשאר שדה ההנחיות של פרויקט פרטי. ההורדה רק אחרי כן, ורק של החבילה הציבורית.

הצעד האחרון, לפני הריאיון, גם כאן וגם בגיבוי:

1. נכנסים ל־chatgpt.com ומתחברים.
2. Projects, פרויקט פרטי חדש. שם חופשי. לא פרויקט משותף.
3. בשדה ההנחיות מדביקים את `web/instructions.md`. באתר יש כפתור «העתקת ההנחיות». זה החלק שחל בכל שיחה חדשה בפרויקט. תקרת 7,000 תווים. T1 עוד תאשר שהשדה מחזיק אותם.
4. בתוכנית החינמית מעלים קובץ אחד: `web/advolog-modules.md` (3 העלאות ביום, 5 קבצים לפרויקט, נבדק 11.11.2026). אם יש יותר העלאות, אפשר את `modules-1` עד `modules-4`. אם הקובץ לא נקרא, `advolog-chatgpt-bundle.md`.
5. מצרפים את `my-record.md` אם כבר יש. זיכרון ברמת הפרויקט, אם האפשרות מופיעה. זה מונע מ־ChatGPT Work לעבוד בתוך הפרויקט (נבדק 11.11.2026). הרשומה היא הקבצים, לא הזיכרון.
6. רק אז שיחה חדשה בתוך הפרויקט, ומתחילים לדבר.

## מסלול גיבוי, בלי אינטרנט או בלי יצירת קבצים

אומרים את זה במפורש, ומדלגים על ההורדה. עושים את הצעד האחרון למעלה. הדבקה מעל 10,000 תווים בצ'אט הופכת לקובץ מצורף. לא מדביקים את טקסט ההקמה ואת ההנחיות בהודעה אחת. אם הופיע קובץ מצורף, «Show in text field».

בטלפון ובאתר שומרים בסוף השיחה קובץ אחד, `my-record.md`. שבעת הקבצים נשארים שווי ערך למי שכבר עובד איתם.

## תיקייה במחשב, או Codex

אם השיחה יכולה לקרוא את המאגר וליצור קבצים, משתמשים בהנחיית ההקמה, לא בהורדת zip ביד. Codex קורא את `AGENTS.md`. המסלול ב־`setup/agents.md`.

## מאמץ

<!-- facts:effort -->
לכל העבודה מספיקה ברירת המחדל, איפה שהתוכנית מציעה אותה. לא מעלים מאמץ רק כי זו הכנה לביקור. המודל החזק יותר מוצע פעם אחת, להחלטה קשה, למידע סותר, או לביורוקרטיה מסובכת, והעוזרת לא מחליפה אותו לבד. השם והבורר בפסקת המודל. אם המסך שונה, המסך קובע.
<!-- /facts:effort -->

## העלאות

לפני כל העלאה חותכים או מכסים את מספר הזהות. מכתב סרוק שעולה כ־PDF עלול להגיע ריק, כי בחלק מהתוכניות נקרא רק הטקסט הדיגיטלי. אם הקובץ ריק, מבקשים צילום של העמוד. בתוכנית החינמית: 3 העלאות ביום (נבדק 11.11.2026).

דף ההכנה נשאר קובץ מלא אחד, לשמירה ולהדפסה, אלא אם השיחה באמת מציעה מסמך אחר. לא מבטיחים פורמט שלא מופיע.

## שיחה חדשה

Projects, הפרויקט, New chat. מצרפים את `my-record.md` (או את שבעת הקבצים), ואז מדביקים את פתק המסירה. פתק לבדו אינו מספיק. אם הקובץ היה רק בארגז כלים זמני, מורידים עותק קודם. «תתעדכני». לפני טיוטה עבור אדם אחר, בודקים שפרופיל נקרא. בלי הסכמה קריאה, או אחרי סירוב, אין טיוטה. הרישום הפרטי נשאר.

## זיכרון

<!-- facts:memory-chatgpt -->
ההמלצה: זיכרון של הפרויקט בלבד (Project-only memory), כדי שהתיק לא יישאב מהזיכרון הכללי ולא יזין אותו. בפרויקט: שלוש הנקודות, Project settings, תחת Memory. נבדק 26.11.2026. זה יכול לקחת כמה שעות. אפשר גם לכבות זיכרון לגמרי. המסך קובע.
<!-- /facts:memory-chatgpt -->

## פרטיות החשבון

מבטלים שימוש בשיחות לאימון. המתג, נבדק 26.11.2026: Improve the model for everyone, תחת Settings ואז Data controls. בחשבון אישי הוא דלוק כברירת מחדל. הצעדים בעמוד הפרטיות באתר. המסך קובע.

OpenAI כותבת, בדף Health in ChatGPT שנקרא ב־26.11.2026: למידע של מישהו אחר, חשבון נפרד או פרויקט נפרד עם זיכרון של הפרויקט בלבד וקבצים שהועלו. ולשיחות הבריאות, פרויקט נפרד עם אותו זיכרון. זה מתאים להקמה כאן, ולמסלול של מי שמתעדת עבור מישהו קרוב, רק בהסכמה. https://help.openai.com/en/articles/20001036-health-in-chatgpt

מ־19.11.2026, שיחות Health יכולות ליצור זיכרון כללי כשהזיכרון דלוק. Health זמין בארצות הברית, לא בישראל.

---

# Setup in ChatGPT

Claude is the primary Anthropic surface. This is the path when the chat is ChatGPT. Model names stay in the facts file. Your screen wins.

Do not keep the record in a shared project. Do not publish the dashboard as a site. Nothing is sent.

## The primary path

When the chat can open the web and create files: check training, memory, web access, and file creation, then paste `prompts/setup-from-repo.md`. That same instruction first checks what is on the screen. On ChatGPT, the place for the instructions stays the private project's Instructions field. The download waits for a yes, and that yes fetches the public package only.

The last step, before onboarding, on this route and on the fallback:

1. Sign in at chatgpt.com.
2. A new private project. Not a shared one.
3. Paste `web/instructions.md` into Instructions. The site button says "copy the instructions". This part applies on every later chat in the project. The cap is 7,000 characters. T1 still confirms the field holds it.
4. On Free, upload one file: `web/advolog-modules.md` (3 uploads a day, 5 files per project, checked 11.11.2026). Where more uploads are allowed, `modules-1` through `modules-4` are fine. If the file is not read, use `advolog-chatgpt-bundle.md`.
5. Attach `my-record.md` if it already exists. Project-only memory, if you see it. That turns ChatGPT Work off inside the project (checked 11.11.2026). The files are the record, not the memory.
6. Only then start a new chat inside the project.

## Fallback, when there is no web access or no file creation

Say so plainly, and skip the download. Do the last step above. A chat paste over 10,000 characters becomes an attachment. Do not paste the setup text and the instructions as one message. If an attachment appears, use "Show in text field".

On the phone and on the web, save one file at the end of a session: `my-record.md`.

## A folder, or Codex

If the chat can read the repository and create files, use the setup text, not a zip downloaded by hand. Codex reads `AGENTS.md`. The path is in `setup/agents.md`.

## Effort

The ordinary default is enough for all of this work. Do not raise effort only because this is visit prep. The optional stronger model, and how to switch to it, is a Claude step. It is named in `platform-facts.md`.

## Uploads

Crop or cover the ID number. A scanned letter uploaded as a PDF may arrive empty. Ask for a photo of the page. On the Free plan: 3 uploads a day (checked 11.11.2026).

The prep sheet is one complete file to save and print, unless the session really offers another document. Do not promise a format you cannot see.

## A new chat

New chat inside the project. Attach `my-record.md` (or the seven files), then paste the handoff note. The note alone is not enough. If the file was only in a temporary sandbox, download a copy first. "Catch up." Before a draft for someone else, check that the profile can be read. Without a readable consent note, or after a decline, there is no draft. Private logging stays.

## Memory

Prefer project-only memory, so the medical project neither draws from nor feeds general memory. In the project: the three dots, Project settings, under Memory, choose Project-only memory. Checked 26.11.2026. It may take a few hours. Or turn memory off. Your screen wins.

## Account privacy

Turn off training on chats. The toggle, checked 26.11.2026, is Improve the model for everyone, under Settings, then Data controls. On a personal account it is on by default. The steps are on the site privacy page. Your screen wins.

OpenAI writes, on the Health in ChatGPT page read on 26.11.2026: for someone else's information, use a separate account or a separate project with project-only memory and uploaded files. For health chats, a separate project with that same memory. That matches this setup, and the path for keeping a record for someone close, only with consent. https://help.openai.com/en/articles/20001036-health-in-chatgpt

From 19.11.2026, Health chats can create general memories when memory is on. Health is available in the United States, not in Israel.
