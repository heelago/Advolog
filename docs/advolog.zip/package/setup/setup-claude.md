# התקנה ב־Claude

Claude הוא המשטח הראשי. Advolog היא חבילה, לא אתר: שום דבר לא עובר דרכנו, ובכל דרך שפותחים אותה, העוזרת מכוונת אל ההקמה הכי מתאימה שיש. העוזרת עונה בשפה שכותבים בה. שמות המודלים רק ב־`platform-facts.md` ובפסקאות שהוא מרנדר. אם המסך שונה, המסך קובע.

הדרך הראשית ב־Claude, אם היא על המסך: פרויקט Claude. זו שיחה ראשית אחת, והיא מפעילה את העבודה בצד. לא צריך לפתוח את החוטים. שיחה ארוכה אחת נעשית כבדה, ופרטים מוקדמים נשמטים. בודקים אם הפרויקט מופיע. אם לא, בודקים אם נשאר פרויקט עם שדה הנחיות. גם Duet, אם הוא על המסך, וגם Dot או Grok Bot, אם כבר נמצאים שם, הם אפשרויות שהעוזרת מציעה ושואלת לפני שהיא ממשיכה. לא מניחים שמוצר קיים.

לא שומרים את הרשומה בפרויקט משותף או בתיקייה משותפת. לא שולחים דבר. ההורדה רק אחרי כן.

## הדרך הראשית

לפני ההדבקה, בודקים ארבעה דברים בחשבון:

1. ביטול שימוש בשיחות לאימון, אם המתג קיים. הניסוח המדויק לא נקרא מחדש בדפדפן. המסך קובע.
2. פרטי בריאות מחוץ לזיכרון.
3. גישה לאינטרנט דלוקה, כדי שהעוזרת תוכל לקרוא את המאגר. אם היא כבויה, עוברים למסלול הגיבוי.
4. יצירת קבצים דלוקה, כדי שהיא תוכל להוריד ולהקים. אם היא כבויה, עוברים למסלול הגיבוי.

ואז מעתיקים את הבלוק העברי מ־`prompts/setup-from-repo.md` לשיחה חדשה. הבלוק האנגלי הוא הכפתור השני באתר. העוזרת קוראת את README, מסבירה מה Advolog ומה היא תעשה, בודקת מה באמת על המסך, וממתינה. רק כן מוריד את החבילה הציבורית. כן הזה אינו הסכמה לשום דבר אחר.

הצעד האחרון, לפני הריאיון, גם אחרי ההורדה וגם במסלול הגיבוי: שומרים את `web/instructions.md` (עד 7,000 תווים. הכפתור באתר נותן את הטקסט) במקום שההקמה שנבחרה שומרת אותו.

- פרויקט Claude, אם הוא על המסך: גלגל השיניים, ואז הנחיות הפרויקט (Project settings, Memory, Project instructions). את `web/advolog-modules.md` ואת `my-record.md`, אם כבר יש, מוסיפים ב־Context או ב־Add context. נשארים בשיחה הראשית. לא פותחים חוטים.
- פרויקט עם שדה הנחיות, אם הוא עדיין על המסך: מדביקים בשדה, מעלים את הקובץ, מצרפים את `my-record.md`, ורק אז שיחה חדשה בתוך הפרויקט.
- תיקייה במחשב: סוגרים ופותחים מחדש את `package/` כדי ש־`CLAUDE.md` ייטען.

בלי הצעד הזה ההנחיות לא נשארות. אם המסך שונה, המסך קובע.

## מסלול גיבוי, בלי אינטרנט או בלי יצירת קבצים

אומרים את זה במפורש, ועושים את אותו צעד אחרון בלי ההורדה מהמאגר. מדביקים את `web/instructions.md` ומעלים קובץ אחד: `web/advolog-modules.md`. אם הקובץ לא נקרא, `advolog-chatgpt-bundle.md`.

ה־zip נשאר למי שכבר מוריד תיקייה ביד. זו לא הדרך הראשית.

העלאת יכולת אחת, למי שכבר משתמש בזה: `advolog-skill.zip`. לפני כן מדליקים יצירת קבצים. `advolog-skills.zip` אינו נתיב ההעלאה.

איפה הרשומה באתר ובטלפון: `my-record.md`, שמירה אחת בסוף. שבעת הקבצים נשארים שווי ערך. לא ממירים בלי בקשה.

## מאמץ ומודל

<!-- facts:effort -->
לכל העבודה מספיקה ברירת המחדל, איפה שהתוכנית מציעה אותה. לא מעלים מאמץ רק כי זו הכנה לביקור. המודל החזק יותר מוצע פעם אחת, להחלטה קשה, למידע סותר, או לביורוקרטיה מסובכת, והעוזרת לא מחליפה אותו לבד. השם והבורר בפסקת המודל. אם המסך שונה, המסך קובע.
<!-- /facts:effort -->

<!-- facts:models-he -->
ברירת המחדל המומלצת, איפה שהתוכנית מציעה אותו: Opus 5.5 במאמץ בינוני. לא מכבים חשיבה. Fable הוא צעד רשות בתוכנית בתשלום, לא בחינם, ורק להחלטה קשה, למידע סותר, או לביורוקרטיה מסובכת. העוזרת מציעה את זה פעם אחת ולא מחליפה לבד. ב־Claude פותחים את בורר המודל ובוחרים Fable. נבדק מול דף הגישה לתוכניות ב־11.11.2026. המסך קובע.
<!-- /facts:models-he -->

## העלאות, וקובץ לרופא או לרופאה

לפני כל העלאה חותכים או מכסים את מספר תעודת הזהות. אם קובץ מגיע ריק או קטוע, אומרים זאת ומבקשים צילום של העמוד. לא מנחשים.

<!-- facts:uploads-claude -->
נבדק 11.11.2026: מסמך לייצוא קיים בכל התוכניות, כולל החינמית, ופתוח כברירת מחדל. בתוכנית החינמית אפשר לשתף בקישור, לא בהזמנה. המסמך פרטי עד שמשתפים אותו. לרופא או לרופאה פשוט יותר לייצא קובץ. לפני שיתוף, רשימת הבדיקה. אם המסמך לא מופיע בשיחה, הדף נמסר כקובץ מלא אחד.
<!-- /facts:uploads-claude -->

## שיחה חדשה

אחרי רישום, או אחרי שתיים־שלוש משימות, מוצעת שיחה חדשה, פעם אחת. בפרויקט Claude חדש לא פותחים שיחה חדשה: נשארים בשיחה הראשית, ומוודאים שהרשומה ב־Context ושההנחיות בהנחיות הפרויקט. שיחה חדשה היא לחשבון שעדיין יש בו שדה הנחיות, ול־ChatGPT. שום דבר לא הולך לאיבוד רק אם בודקים שההמשך באמת פותח את אותו `my-record.md` (או את שבעת הקבצים), ושההנחיות הקבועות כבר שמורות. אם הקובץ נשאר רק בארגז כלים זמני, מורידים עותק לפני המעבר. פתק לבדו אינו מספיק. במחשב הפתק נשמר כ־`handoff.md` ליד הקבצים. מילת פתיחה: «תתעדכני». לפני טיוטה עבור אדם אחר, בודקים שהפרופיל נקרא. אם אין הסכמה, או שהיא לא נקראת, לא כותבים את הטיוטה, ואומרים למה. הרישום הפרטי נשאר.

## זיכרון

בריאות לא שייכת לזיכרון ארוך הטווח. הרשומה היא הקבצים.

<!-- facts:memory-claude -->
איפה המתג יושב, ומה שמו, ממתין לאימות בקובץ העובדות. ההמלצה עד אז: להשאיר פרטי בריאות מחוץ לזיכרון, במיוחד כשמתעדים עבור אדם אחר. מה שמופיע אצלכם הוא הקובע.
<!-- /facts:memory-claude -->

## פרטיות החשבון, שתי דקות

מבטלים שימוש בשיחות לאימון, איפה שהתוכנית מאפשרת. הצעדים המדויקים ממתינים לאימות ב־`platform-facts.md` ובדף `privacy.html` באתר. המסך קובע.

---

# Setup in Claude

Claude is the primary surface. Advolog is a package, not a site: nothing passes through us, and whichever way you open it, your assistant guides you to the best available setup. The assistant answers in the language you write. Model names appear only in `platform-facts.md` and in the paragraphs it renders. If your screen differs, your screen wins.

The primary Claude route, when it is on the screen: a Claude Project. That is one main conversation, and it starts the side work. You do not open the threads. One long session gets heavy, and early details slip. Check whether the Project is there. If it is not, check whether an older project with an Instructions field is still there. Duet, if it is on the screen, and Dot or Grok Bot, if you are already there, are options the assistant suggests and asks about before it continues. Do not assume a product is present.

Do not keep the record in a shared project or a shared folder. Nothing is sent. A download waits for a yes.

## The primary path

Before pasting, check four things:

1. Turn off training on chats if the switch exists. The exact wording was not re-read in a browser. Your screen wins.
2. Keep health details out of memory.
3. Web access on, so the assistant can read the repository. If it is off, use the fallback.
4. File creation on, so it can download and set up. If it is off, use the fallback.

Then paste the Hebrew block from `prompts/setup-from-repo.md` into a new chat. The English block is the second button on the site. The assistant reads the README, explains what Advolog is and what it will do, checks what is actually on the screen, and waits. Only a yes downloads the public package. That yes is not consent for anything else.

The last step, before onboarding, on the web route and on the fallback: save `web/instructions.md` (at most 7,000 characters; the site button gives that text) where the chosen setup keeps it.

- A Claude Project, if it is on the screen: the gear, then Project instructions (Project settings, Memory, Project instructions). Add `web/advolog-modules.md` and `my-record.md`, if it already exists, in Context or Add context. Stay in the main conversation. Do not open the threads.
- A project with an Instructions field, if it is still on the screen: paste into the field, upload the file, attach `my-record.md`, and only then open a new chat inside the project.
- A folder on a computer: close and reopen `package/` so `CLAUDE.md` or `AGENTS.md` is in scope.

Without that step the instructions do not stay. If the screen differs, the screen wins.

## Fallback, when there is no web access or no file creation

Say so plainly, and do that same last step without fetching the repository. Paste `web/instructions.md` and upload one file, `web/advolog-modules.md`. On ChatGPT Free that is also the upload cap. If that file is not read, use `advolog-chatgpt-bundle.md`.

The zip remains for someone who already downloads a folder by hand. It is not the primary path.

One skill upload, for people who already use that: `advolog-skill.zip`, with file creation on. `advolog-skills.zip` is not the upload path.

On the web and on a phone, the record is one file, `my-record.md`, one save at the end. The seven files stay equivalent. Do not convert unless asked.

## Effort and model

The recommended default is medium effort where the plan offers it. Do not raise effort only because this is visit prep.

<!-- facts:models-en -->
The recommended default, where the plan offers it: Opus 5.5 at medium effort. Do not turn thinking off. Fable is an optional step on a paid plan, not on Free, and only for a hard decision, conflicting information, or complex bureaucracy. The assistant offers it once and does not switch it itself. In Claude, open the model picker and choose Fable. Checked against the plan-access page on 11.11.2026. Your screen wins.
<!-- /facts:models-en -->

## Uploads, and a file for the doctor

Crop or cover the ID number before every upload. If a file arrives empty, say so and ask for a photo. Do not guess.

Checked 11.11.2026: an exportable document exists on every plan, including Free, and is on by default. On Free, sharing is by link, not by invitation. The document stays private until shared. For the doctor, export a file. The checklist comes first. If this session has no such document, the page is one complete file to save and print.

## A new chat

After a log, or after two or three tasks, a new chat is offered once. On a new Claude Project, do not open a new chat: stay in the main conversation, and check that the record is in Context and the instructions are in Project instructions. A new chat is for an account that still has an Instructions field, and for ChatGPT. Nothing is lost only if you check that the continuation actually opens the same `my-record.md` (or the seven files), and that the standing instructions are already saved. If the file is only in a temporary sandbox, download a copy before you move. The note alone is not enough. On a computer the note is `handoff.md` beside the files. Opening word: "catch up". Before a draft for someone else, check that the profile can be read. If consent is missing, unreadable, or declined, do not write the draft, and say why. Private logging stays.

## Memory

Health details do not belong in long-term memory. The files are the record. Where the switch sits is pending verification. Until then, keep health details out of memory, especially when the record is for someone else.

## Account privacy

Turn off training on chats where the plan allows it. The exact clicks are pending verification, on `privacy.html`. Your screen wins.
