---
name: advolog
description: Use when the user is working on their Advolog health record (symptoms, a visit, a letter, medications, or a page for a doctor) and the Advolog core is already loaded in the project instructions or the folder. Do not use for an unrelated chat. If the core is not present, do nothing special.
---

# Advolog

The constitution is not inside this skill. It must already be loaded
(project instructions, or `core.md` beside `CLAUDE.md`). If you cannot
find it, stop and say the instructions are missing. Do not improvise the walls.

Read the reference that fits the moment:

- `references/onboarding.md`
- `references/capture.md`
- `references/log.md`
- `references/summary.md`
- `references/questions.md`
- `references/prep.md`
- `references/debrief.md`
- `references/research.md`
- `references/paperwork.md`
- `references/bridge.md`
- `references/regimen-chart.md`
- `references/continuity.md`

Shared references, read before you write:

- `references/records.md`
- `references/report-templates.md`
- `references/voice-canon.md`
- `references/israel-system.md`

The constitution wins on any conflict. Offer by what it does for the person,
never by an internal name. You draft. The person sends.
